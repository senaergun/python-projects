# open input file
assignment2 = open("doctors_aid_inputs.txt")
# open output file
output_file = open("doctors_aid_outputs.txt", "w")

# create an empty command list
command_list = []
# create an empty patient list
patient_list = []

for line in assignment2:
    line = line.replace(" ", ",").replace(",,", ",")
    line = line.split(",")
    line[-1] = line[-1].replace("\n", "")
    command_list.append(line)
for line in command_list:
    if line[0] == "create":
        create()
    if line[0] == "remove":
        remove()
    if line[0] == "list":
        list()
    if line[0] == "probability":
        name = line[1]
        probability()
    if line[0] == "recommendation":
        name = line[1]
        recommendation()


        def create():
            if line[1] in patient_list:
                output_file.write("Patient " + line[1] + " cannot be recorded due to duplication.\n")
            else:
                patient_list.append(line[1])
                output_file.write("Patient " + line[1] + " is recorded.\n")


        def remove():
            if line[1] not in patient_list:
                output_file.write("Patient " + line[1] + " cannot be removed due to absence.")
            else:
                patient_list.remove(line[1])
                b = "Patient " + line[1] + " is removed.\n"
                output_file.write(b)


        def list():
            output_file.write(
                "Patient\tDiagnosis  \t\tDisease\t\tDisease\t\tTreatment\t\tTreatment\nName\tAccuracy  \t\tName\t\tIncidence\t\tName\t\tRisk\n" + 73 * "-" + "\n")
            for line in command_list:
                if len(line) == 9:
                    treatment_1 = line[6]
                    treatment_2 = line[7]
                    line = line[:6] + [line[8]]
                    line.insert(-1, treatment_1 + "" + treatment_2)
                if line[0] == "create":
                    percentage = float(line[2]) * 100
                    percentage = f"{percentage:.2f}" + "%"
                    percentage_surgery = round(float(line[-1]) * 100)
                    percentage_surgery = str(percentage_surgery) + "%"
                    output_file.write(
                        line[1] + "\t" + percentage + "  \t\t\t" + line[3] + " " + line[4] + "\t" + line[5] + "\t\t" +
                        line[6] + "\t" + percentage_surgery + "\n")


        def probability():
            if name in patient_list:

                for line in command_list:
                    if line[0] == "create" and line[1] == name:
                        calculation = line[5].split("/")
                        s = ((1 - float(line[2])) * (float(calculation[1]) - float(calculation[0]))) + float(
                            calculation[0])
                        prob = int(calculation[0]) / s * 100
                        prob = f"{prob:.2f}"
                        if name in patient_list:
                            output_file.write(
                                "Patient " + line[1] + " has a probability of " + prob + "% of having " + line[
                                    3] + " " + line[4] + ".\n")
            else:
                output_file.write("Probability for " + name + " cannot be calculated due to absence.\n")

        def recommendation():
            if name in patient_list:
                for line in command_list:
                    if line[0] == "create" and line[1] == name:
                        calculation = line[5].split("/")
                        g = ((1 - float(line[2])) * (float(calculation[1]) - float(calculation[0]))) + float(
                            calculation[0])
                        recom = int(calculation[0]) / g * 100
                        recom = f"{recom:.2f}"

                        if line[1] in patient_list:
                            if float(recom) < float(line[-1]) * 100:
                                output_file.write("System suggests " + name + " NOT to have the treatment.\n")
                            else:
                                output_file.write("System suggests " + name + " to have the treatment.\n")

            else:
                output_file.write("Recommendation for " + name + " cannot be calculated due to absence.\n")

# Gül Sena Ergun
# 2210356113
