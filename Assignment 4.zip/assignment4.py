import sys

error_list = []
output = open("Battleship.out", "w")

for item in sys.argv[1:5]:
    try:
        if item == sys.argv[1]:
            player1_input_file = open(sys.argv[1], "r")
        if item == sys.argv[2]:
            player2_input_file = open(sys.argv[2], "r")
        if item == sys.argv[3]:
            player1_in_file = open(sys.argv[3], "r")
        if item == sys.argv[4]:
            player2_in_file = open(sys.argv[4], "r")
    except IOError:
        error_list.append(item)
    except:
        output.write("kaBOOM: run for your life!")
        print("kaBOOM: run for your life!")
        sys.exit()

if len(error_list)>0:
    # Convert error_list to string to prompt to the output file
    error_txt = ""
    for item in error_list:
        item = item + " "
        error_txt = error_txt + item
        error_txt.strip()
    error_txt = error_txt.replace(" ", ", ")
    output.write("IOError: input file(s) {} is/are not reachable.".format(error_txt))
    print("IOError: input file(s) {} is/are not reachable.".format(error_txt))
    sys.exit()
else:
    player1_input = []
    player2_input = []

    for line in player1_input_file:
        line = line.strip()
        line = line.split(";")
        player1_input.append(line)

    for line in player2_input_file:
        line = line.strip()
        line = line.split(";")
        player2_input.append(line)

    player1_board = []
    player2_board = []
    square_dict = {"class_ship": "undefined", "label": "-", "label_hidden": "-", "status": "-"}

    for i in range(10):
        row = []
        for j in range(10):
            row.append(square_dict.copy())
        player1_board.append(row)
    for i in range(10):
        row = []
        for j in range(10):
            row.append(square_dict.copy())
        player2_board.append(row)

    row_idx = 0
    column_idx = 0

    for row in player1_input:
        row_idx += 1
        for square in row:
            if column_idx <= 9:
                column_idx +=1
            else:
                column_idx = 1

            square_dict = player1_board[row_idx-1][column_idx-1]
            # Update square_dict dictionaries with respect to given input
            if square == "C":
                square_dict.update({"class_ship": "Carrier", "label": "C", "label_hidden": "C", "status": "-"})
            if square == "B":
                square_dict.update({"class_ship": "Battleship", "label": "B", "label_hidden": "B", "status": "-"})
            if square == "D":
                square_dict.update({"class_ship": "Destroyer", "label": "D", "label_hidden": "D", "status": "-"})
            if square == "S":
                square_dict.update({"class_ship": "Submarine", "label": "S", "label_hidden": "S", "status": "-"})
            if square == "P":
                square_dict.update({"class_ship": "Patrol Boat", "label": "P", "label_hidden": "P", "status": "-"})

    row_idx = 0
    column_idx = 0

    for row in player2_input:
        row_idx += 1
        for square in row:
            if column_idx <= 9:
                column_idx +=1
            else:
                column_idx = 1

            square_dict = player2_board[row_idx-1][column_idx-1]
            # Update square_dict dictionaries with respect to given input
            if square == "C":
                square_dict.update({"class_ship": "Carrier", "label": "C", "label_hidden": "C", "status": "-"})
            if square == "B":
                square_dict.update({"class_ship": "Battleship", "label": "B", "label_hidden": "B",  "status": "-"})
            if square == "D":
                square_dict.update({"class_ship": "Destroyer", "label": "D", "label_hidden": "D", "status": "-"})
            if square == "S":
                square_dict.update({"class_ship": "Submarine", "label": "S", "label_hidden": "S", "status": "-"})
            if square == "P":
                square_dict.update({"class_ship": "Patrol Boat", "label": "P", "label_hidden": "P",  "status": "-"})



    optional_player1_txt = open("OptionalPlayer1.txt", "r")
    optional_player2_txt = open("OptionalPlayer2.txt", "r")
    optional_player1 = []
    optional_player2 = []

    for line in optional_player1_txt:
        line = line.replace(";", ",")
        line = line.replace(":", ",")
        line = line.strip()
        line = line.split(",")
        optional_player1.append(line)

    for line in optional_player2_txt:
        line = line.replace(";", ",")
        line = line.replace(":", ",")
        line = line.strip()
        line = line.split(",")
        optional_player2.append(line)

    alf = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]

    # Created a function which separates multiple ships
    def shipcheck(board, row):
        if (row[0] == "B1" or row[0] == "B2") and row[3] == "right":
            label_hidden = row[0]
            row_idx = row[1]
            column_idx_start = alf.index(row[2]) + 1
            column_idx_end = column_idx_start + 3

            for column_idx in range(column_idx_start, column_idx_end + 1):
                square_dict = board[int(row_idx) - 1][int(column_idx) - 1]
                square_dict.update({"label_hidden": label_hidden})
        if (row[0] == "B1" or row[0] == "B2") and row[3] == "down":
            label_hidden = row[0]
            column_idx = alf.index(row[2]) + 1
            row_idx_start = row[1]
            row_idx_end = int(row_idx_start) + 3
            for row_idx in range(int(row_idx_start), row_idx_end + 1):
                square_dict = board[int(row_idx) - 1][int(column_idx) - 1]
                square_dict.update({"label_hidden": label_hidden})
        if (row[0] == "P1" or row[0] == "P2" or row[0] == "P3" or row[0] ==  "P4") and row[3] == "right":
            label_hidden = row[0]
            row_idx = row[1]
            column_idx_start = alf.index(row[2]) + 1
            column_idx_end = column_idx_start + 1
            for column_idx in range(column_idx_start, column_idx_end + 1):
                square_dict = board[int(row_idx) - 1][int(column_idx) - 1]
                square_dict.update({"label_hidden": label_hidden})
        if (row[0] == "P1" or row[0] ==  "P2" or row[0] == "P3" or row[0] ==  "P4") and row[3] == "down":
            label_hidden = row[0]
            column_idx = alf.index(row[2]) + 1
            row_idx_start = row[1]
            row_idx_end = int(row_idx_start) + 1
            for row_idx in range(int(row_idx_start), int(row_idx_end) + 1):
                square_dict = board[row_idx - 1][column_idx - 1]
                square_dict.update({"label_hidden": label_hidden})

    for input in optional_player1:
        shipcheck(player1_board, input)
    for input in optional_player2:
        shipcheck(player2_board, input)


    player1_in = player1_in_file.read()
    player1_in = player1_in.strip()
    player1_in = player1_in.split(";")
    player1_in_old = player1_in.copy()

    player2_in = player2_in_file.read()
    player2_in = player2_in.strip()
    player2_in = player2_in.split(";")
    player2_in_old = player2_in.copy()

    # Created a function that collects all the values which belongs to "status" key in the dictionaries in a status_list
    def statuslist(board):
        status_list = []
        for row in board:
            rows = []
            for square_dict in row:
                rows.append(square_dict["status"])
            status_list.append(rows)
        return status_list


    # Created a function that collects all the values which belongs to "label_hidden" key
    # in the dictionaries in a label_list
    def hiddenlabellist(board):
        label_list = []
        for row in board:
            a = []
            for square_dict in row:
                a.append(square_dict["label_hidden"])
            label_list.append(a)
        return label_list


    # Created a function that collects all the values which belongs to "label" key in the dictionaries in a label_list
    def labellist(board):
        label_list = []
        for row in board:
            a = []
            for square_dict in row:
                a.append(square_dict["label"])
            label_list.append(a)
        return label_list

    # Created a function that calculates the ship size
    def count_size(board):
        label_list = hiddenlabellist(board)
        global count_C, count_B1, count_B2, count_D, count_S, count_P1, count_P2, count_P3, count_P4
        (count_C, count_B1, count_B2, count_D, count_S, count_P1, count_P2, count_P3, count_P4) = (0, 0, 0, 0, 0, 0, 0, 0, 0)

        for line in label_list:
            count_C = count_C + line.count("C")
            count_B1 = count_B1 + line.count("B1")
            count_B2 = count_B2 + line.count("B2")
            count_D = count_D + line.count("D")
            count_S = count_S + line.count("S")
            count_P1 = count_P1 + line.count("P1")
            count_P2 = count_P2 + line.count("P2")
            count_P3 = count_P3 + line.count("P3")
            count_P4 = count_P4 + line.count("P4")

    # Created a function which checks user input and replaces invalid inputs in the list with 'invalid move',
    # 'invalid square' or 'invalid value'
    def checkinput(move, player):
        try:
            assert len(move) == 3 or len(move) == 4
        except AssertionError:
            idx = player.index(move)
            if len(move) == 0:
                player.remove(move)
            if len(move) == 1 or len(move) == 2:
                player[idx] = "invalid move"
        try:
            if len(move) ==3:
                row_num = move[0]
                col_num = alf.index(move[2]) + 1
                if not (int(row_num) <= 10 and (int(row_num) >= 1) and (int(col_num) <= 10) and (int(col_num) >= 1)):
                    raise AssertionError
            if len(move) ==4:
                row_num = int(move[0])*10 + int(move[1])
                col_num = alf.index(move[3]) + 1
                if not (int(row_num) <= 10 and (int(row_num) >= 1) and (int(col_num) <= 10) and (int(col_num) >= 1)):
                    raise AssertionError

        except AssertionError:
            idx = player.index(move)
            player[idx] = "invalid square"
        except ValueError:
            idx = player.index(move)
            player[idx] = "invalid value"


    # Created a function that shows how many ships are left for all ship types
    def showstatus():
        count_size(player1_board)
        if count_C > 0:
            output.write("Carrier" + "\t  " + "  " + "-\t\t\t\t")
            print("Carrier" + "\t  " + "  " + "-\t\t\t\t", end = " " )
        if count_C == 0:
            output.write("Carrier" + "\t  " + "  " + "X\t\t\t\t")
            print("Carrier" + "\t  " + "  " + "X\t\t\t\t", end=" ")
        count_size(player2_board)
        if count_C > 0:
            output.write("Carrier" + "\t  " + "  " + "-\n")
            print("Carrier" + "\t  " + "  " + "-")
        if count_C == 0:
            output.write("Carrier" + "\t  " + "  " + "X\n")
            print("Carrier" + "\t  " + "  " + "X")

        count_size(player1_board)
        if (count_B1 + count_B2) == 0:
            output.write("Battleship" + "\t" + "X X\t\t\t")
            print("Battleship" + "\t" + "X X\t\t\t", end=" ")
        else:
            if count_B1 > 0:
                if count_B2 == 0:
                    output.write("Battleship" + "\t" + "X -\t\t\t")
                    print("Battleship" + "\t" + "X -\t\t\t", end=" ")
                    print("\t", end=" ")
                if count_B1 > 0:
                    output.write("Battleship" + "\t" + "- -\t\t\t")
                    print("Battleship" + "\t" + "- -\t\t\t", end=" ")
                    print("\t", end=" ")

            if count_B2 > 0:
                if count_B1 == 0:
                    output.write("Battleship" + "\t" + "X -\t\t\t")
                    print("Battleship" + "\t" + "X -\t\t\t\t", end=" ")


        count_size(player2_board)
        if (count_B1 + count_B2) == 0:
            output.write("\tBattleship" + "  " + "X X\n")
            print("\tBattleship" + "  " + "X X")

        if count_B1 > 0:
            if count_B2 == 0:
                output.write("\tBattleship" + "\t" + "X -\n")
                print("\tBattleship" + "\t" + "X -")
            if count_B1 > 0:
                output.write("\tBattleship" + "\t" + "- -\n")
                print("\tBattleship" + "\t" + "- -")
        if count_B2 > 0:
            if count_B1 == 0:
                output.write("\tBattleship" + "\t" + "X -\n")
                print("\tBattleship" + "\t" + "X -")

        count_size(player1_board)
        if count_D > 0:
            output.write("Destroyer" + "\t-\t\t\t\t")
            print("Destroyer" + "\t-\t\t\t\t", end=" ")
        if count_D == 0:
            output.write("Destroyer" + "\tX\t\t\t\t")
            print("Destroyer" + "\tX\t\t\t\t", end=" ")
        count_size(player2_board)
        if count_D > 0:
            output.write("Destroyer" + "\t-\n")
            print("Destroyer" + "\t-")
        if count_D == 0:
            output.write("Destroyer" + "\tX\n")
            print("Destroyer" + "\tX")

        count_size(player1_board)
        if count_S > 0:
            output.write("Submarine" + "\t-\t\t\t\t")
            print("Submarine" + "\t-\t\t\t\t", end=" ")
        if count_S == 0:
            output.write("Submarine" + "\tX\t\t\t\t")
            print("Submarine" + "\tX\t\t\t\t", end=" ")
        count_size(player2_board)
        if count_S > 0:
            output.write("Submarine" + "\t-\n")
            print("Submarine" + "\t-")
        if count_S == 0:
            output.write("Submarine" + "\tX\n")
            print("Submarine" + "\tX")

        count_size(player1_board)
        if count_P1 + count_P2 + count_P3 + count_P4 == 0:
            output.write("Patrol Boat" + "\t" + "X X X X\t\t\t")
            print("Patrol Boat" + "\t" + "X X X X\t\t\t", end=" ")
        else:
            PB_list = []
            for Patrol_Boat in (count_P1, count_P2, count_P3, count_P4):
                if Patrol_Boat > 0:
                    PB_list.append(str(Patrol_Boat))
            if len(PB_list) == 1:
                output.write("Patrol Boat" + "\t" + "X X X -\t\t\t")
                print("Patrol Boat" + "\t" + "X X X -\t\t\t", end=" ")

            if len(PB_list) == 2:
                output.write("Patrol Boat" + "\t" + "X X  - -\t\t\t")
                print("Patrol Boat" + "\t" + "X X  - -\t\t\t", end=" ")

            if len(PB_list) == 3:
                output.write("Patrol Boat" + "\t" + "X - - -\t\t\t")
                print("Patrol Boat" + "\t" + "X - - -\t\t\t", end=" ")

            if len(PB_list) == 4:
                output.write("Patrol Boat" + "\t" + "- - - -\t\t\t")
                print("Patrol Boat" + "\t" + "- - - -\t\t\t", end=" ")

        count_size(player2_board)
        if count_P1 + count_P2 + count_P3 + count_P4 == 0:
            output.write("Patrol Boat" + "\t" + "X X X X\n\n")
            print("Patrol Boat" + "\t" + "X X X X\n")
        else:
            PB_list = []
            for Patrol_Boat in (count_P1, count_P2, count_P3, count_P4):
                if Patrol_Boat > 0:
                    PB_list.append(str(Patrol_Boat))
            if len(PB_list) == 1:
                output.write("Patrol Boat" + "\t" + "X X X -\n\n")
                print("Patrol Boat" + "\t" + "X X X -\n")
            if len(PB_list) == 2:
                output.write("Patrol Boat" + "\t" + "X X  - -\n\n")
                print("Patrol Boat" + "\t" + "X X  - -\n")
            if len(PB_list) == 3:
                output.write("Patrol Boat" + "\t" + "X - - -\n\n")
                print("Patrol Boat" + "\t" + "X - - -\n")
            if len(PB_list) == 4:
                output.write("Patrol Boat" + "\t" + "- - - -\n\n")
                print("Patrol Boat" + "\t" + "- - - -\n")

    for move in player1_in:
        checkinput(move, player1_in)
    for move in player2_in:
        checkinput(move, player2_in)

    num_sunk1 = 0
    num_sunk2 = 0
    round_count = -1

    output.write("Battle of Ships Game\n\n")
    print("Battle of Ships Game\n")
    row_nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    # Set a variable to determine which player will play
    turn = 1
    error = False
    again = False

    # Start a while loop to play the game until a player has no ships left
    while num_sunk1 < 27 and num_sunk2 < 27:
        round_count += 1
        if turn == 1:
            try:
                if error == False:

                    output.write("Player1's Move\n\n")
                    output.write("Round : " + str(round_count + 1) + "\t\t\t\t\tGrid Size: 10x10\n\n")
                    print("Player1's Move\n")
                    print(("Round : " + str(round_count + 1) + "\t\t\t\t\tGrid Size: 10x10\n"))

                    # Prompt board to the output file
                    output.write("Player1's Hidden Board\t\t")
                    output.write("Player2's Hidden Board\n")
                    print("Player1's Hidden Board\t\t", end=" ")
                    print("Player2's Hidden Board")
                    format_row = "{:>3}" + "{:>2}" * 9
                    output.write(format_row.format(*alf))
                    output.write("\t\t")
                    output.write(format_row.format(*alf))
                    output.write("\n")
                    print(format_row.format(*alf), "\t\t", format_row.format(*alf))

                    player1_statuslist = statuslist(player1_board)
                    player2_statuslist = statuslist(player2_board)

                    format_row = "{:<2}" * 11 + "{:<2}" * 12
                    for row_num, status1, row_num, status2 in zip(row_nums, player1_statuslist, row_nums, player2_statuslist):
                        output.write(format_row.format(row_num, *status1,"\t\t", row_num, *status2))
                        output.write("\n")
                        print(format_row.format(row_num, *status1,"\t\t", row_num, *status2))
                    output.write("\n")
                    print("\n")
                    showstatus()

                if error == False or again == True:

                    if player1_in[round_count] == "invalid square":
                        idx = player1_in.index("invalid square")
                        output.write("Enter your move: " + player1_in_old[idx] + "\n")
                        print("Enter your move: " + player1_in_old[idx])
                        raise AssertionError
                    if player1_in[round_count] == "invalid move":
                        idx = player1_in.index("invalid move")
                        output.write("Enter your move: " + player1_in_old[idx] + "\n")
                        print("Enter your move: " + player1_in_old[idx])
                        raise IndexError
                    if player1_in[round_count] == "invalid value":
                        idx = player1_in.index("invalid value")
                        output.write("Enter your move: " + player1_in_old[idx] + "\n")
                        print("Enter your move: " + player1_in_old[idx])
                        raise ValueError

                    else:
                        if len(player1_in[round_count]) == 5 or len(player1_in[round_count]) == 6:
                            raise NameError

                        else:
                            output.write("Enter your move: " + player1_in[round_count] + "\n\n")
                            print("Enter your move: " + player1_in[round_count] + "\n")

                    # Determine row and column index
                    if len(player1_in[round_count]) == 3:
                        row_num = player1_in[round_count][0]
                        col_idx = alf.index(player1_in[round_count][2])
                    if len((player1_in[round_count])) == 4:
                        row_num = int(player1_in[round_count][0]) * 10 + int(player1_in[round_count][1])
                        col_idx = alf.index(player1_in[round_count][3])
                    row_idx = int(row_num) - 1

                    square_dict = player2_board[row_idx][col_idx]
                    if square_dict["status"] == "O" or square_dict["status"] == "X":
                        raise Exception
                    if square_dict["label_hidden"] != "-":
                        if square_dict["label_hidden"] == "C":
                            num_sunk2 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "B1":
                            num_sunk2 += 1
                            square_dict.update({"label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "B2":
                            num_sunk2 += 1
                            square_dict.update({"label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "D":
                            num_sunk2 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "S":
                            num_sunk2 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "P1":
                            num_sunk2 += 1
                            square_dict.update({"label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "P2":
                            num_sunk2 += 1
                            square_dict.update({"label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "P3":
                            num_sunk2 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "P4":
                            num_sunk2 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                    if square_dict["label_hidden"] == "-":
                        square_dict.update({"status": "O", "label": "O"})
                    turn = 2
                    error = False
                    again = False
            except AssertionError:
                turn = 1
                output.write("AssertionError: Invalid Operation\n")
                print("AssertionError: Invalid Operation")
                player1_in.pop(idx)
                round_count += -1
                error = True
                again = True
                continue

            except IndexError:
                try:
                    idx = player1_in.index("invalid move")
                    if len(player1_in_old[idx]) == 1:
                        if player1_in_old[idx] == ",":
                            output.write("IndexError: You must enter a number and a letter to specify row and column\n")
                            print("IndexError: You must enter a number and a letter to specify row and column")
                        elif player1_in_old[idx] in alf:
                            output.write("IndexError: You must enter a number to specify row and put a comma between values\n")
                            print("IndexError: You must enter a number to specify row and put a comma between values")
                        else:
                            output.write("IndexError: You must enter a letter to specify column and put a comma between values\n")
                            print("IndexError: You must enter a letter to specify column and put a comma between values")
                    if len(player1_in_old[idx]) == 2:
                        if player1_in_old[idx][0] == ",":
                            output.write("IndexError: You must enter a number to specify row\n")
                            print("IndexError: You must enter a number to specify row")
                        if player1_in_old[idx][1] == ",":
                            output.write("IndexError: You must enter a letter to specify column\n")
                            print("IndexError: You must enter a letter to specify column")
                    else:
                        pass
                    player1_in.pop(idx)
                    round_count += -1
                    turn = 1
                    error = True
                    again = True
                    continue
                except:
                    output.write("kaBOOM: run for your life!")
                    print("kaBOOM: run for your life!")
                    sys.exit()

            except ValueError:
                try:
                    idx = player1_in.index("invalid value")
                    if player1_in_old[idx][0] in alf:
                        if player1_in_old[idx][2] in alf:
                            output.write("ValueError: You must first enter a number instead of a letter to specify row\n")
                            print("ValueError: You must first enter a number instead of a letter to specify row")
                        else:
                            output.write("ValueError: You must first enter a number and then a letter to specify the  row and column\n")
                            print(("ValueError: You must first enter a number instead of a letter to specify row"))
                    elif int(player1_in_old[idx][0]) < 11 and int(player1_in_old[idx][0]) > 0:
                        output.write("ValueError: You must enter a letter as the second value to specify column\n")
                        print("ValueError: You must enter a letter as the second value to specify column")
                    else:
                        pass
                    player1_in.pop(idx)
                    round_count += -1
                    turn= 1
                    error = True
                    again = True
                    continue
                except:
                    output.write("kaBOOM: run for your life!")
                    print("kaBOOM: run for your life!")
                    sys.exit()

            except NameError:
                output.write("Enter your move: " + player1_in[round_count] + "\n")
                print("Enter your move: " + player1_in[round_count])
                output.write("ValueError: You must enter semicolons between your moves\n")
                print("ValueError: You must enter semicolons between your moves")
                idx = player1_in.index(player1_in[round_count])
                player1_in.pop(idx)
                round_count += -1
                turn = 1
                error = True
                again = True
                continue

            except Exception:
                if square_dict["status"] == "O" or square_dict["status"] == "X":
                    output.write("AssertionError: Invalid Operation\n")
                    print("AssertionError: Invalid Operation")
                    idx = player1_in.index(player1_in[round_count])
                    player1_in.pop(idx)
                    round_count += -1
                    turn = 1
                    error = True
                    again = True
                    continue
                else:
                    output.write("kaBOOM: run for your life!")
                    print("kaBOOM: run for your life!")
                    sys.exit()

        if turn == 2:

            try:
                if error == False:

                    output.write("Player2's Move\n\n")
                    output.write("Round : " + str(round_count + 1) + "\t\t\t\t\tGrid Size: 10x10\n\n")
                    print("Player2's Move\n")
                    print("Round : " + str(round_count + 1) + "\t\t\t\t\tGrid Size: 10x10\n")

                    # Prompt board to the output file
                    output.write("Player1's Hidden Board\t\t")
                    output.write("Player2's Hidden Board\n")
                    print("Player1's Hidden Board\t\tPlayer2's Hidden Board")
                    format_row = "{:>3}" + "{:>2}" * 9
                    output.write(format_row.format(*alf))
                    output.write("\t\t")
                    output.write(format_row.format(*alf))
                    output.write("\n")
                    print(format_row.format(*alf), "\t\t", format_row.format(*alf))

                    player1_statuslist = statuslist(player1_board)
                    player2_statuslist = statuslist(player2_board)

                    format_row = "{:<2}" * 11 + "{:<2}" * 12
                    for row_num, status1, row_num, status2 in zip(row_nums, player1_statuslist, row_nums, player2_statuslist):
                        output.write(format_row.format(row_num, *status1, "\t\t", row_num, *status2))
                        output.write("\n")
                        print(format_row.format(row_num, *status1, "\t\t", row_num, *status2))
                    output.write("\n")
                    print("\n")
                    showstatus()

                if error == False or again == True:
                    if player2_in[round_count] == "invalid square":
                        idx = player2_in.index("invalid square")
                        output.write("Enter your move: " + player2_in_old[idx] + "\n")
                        print("Enter your move: " + player2_in_old[idx])
                        raise AssertionError
                    if player2_in[round_count] == "invalid move":
                        idx = player2_in.index("invalid move")
                        output.write("Enter your move: " + player2_in_old[idx] + "\n")
                        print("Enter your move: " + player2_in_old[idx])
                        raise IndexError
                    if player2_in[round_count] == "invalid value":
                        idx = player2_in.index("invalid value")
                        output.write("Enter your move: " + player2_in_old[idx] + "\n")
                        print("Enter your move: " + player2_in_old[idx])
                        raise ValueError
                    else:
                        if len(player2_in[round_count]) == 5 or len(player2_in[round_count]) == 6:
                            raise NameError
                        else:
                            output.write("Enter your move: " + player2_in[round_count] + "\n\n")
                            print("Enter your move: " + player2_in[round_count] + "\n")



                    # Determine row and column index
                    if len(player2_in[round_count]) ==3:
                        row_num = player2_in[round_count][0]
                        col_idx = alf.index(player2_in[round_count][2])
                    if len((player2_in[round_count])) ==4:
                        row_num = int(player2_in[round_count][0])*10 + int(player2_in[round_count][1])
                        col_idx = alf.index(player2_in[round_count][3])
                    row_idx = int(row_num) - 1

                    square_dict = player1_board[row_idx][col_idx]
                    if square_dict["status"] == "O" or square_dict["status"] == "X":
                        raise Exception
                    if square_dict["label_hidden"] != "-":
                        if square_dict["label_hidden"] == "C":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "B1":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "B2":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "D":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "S":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "P1":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "P2":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "P3":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                        if square_dict["label_hidden"] == "P4":
                            num_sunk1 += 1
                            square_dict.update({"label": "X", "label_hidden": "X", "status": "X"})
                    if square_dict["label_hidden"] == "-":
                        square_dict.update({"status": "O", "label": "O"})
                    turn = 1
                    error = False
                    again = False

            except AssertionError:
                output.write("AssertionError: Invalid Operation\n")
                print("AssertionError: Invalid Operation")
                player2_in.pop(idx)
                round_count += -1
                turn = 2
                error = True
                again = True
                continue
            except IndexError:
                try:
                    idx = player2_in.index("invalid move")
                    if len(player2_in_old[idx]) == 1:
                        if player2_in_old[idx] == ",":
                            output.write("IndexError: You must enter a number and a letter to specify row and column\n")
                            print("IndexError: You must enter a number and a letter to specify row and column")
                        elif player2_in_old[idx] in alf:
                            output.write("IndexError: You must enter a number to specify row and put a comma between values\n")
                            print("IndexError: You must enter a number to specify row and put a comma between values")
                        else:
                            output.write("IndexError: You must enter a letter to specify column and put a comma between values\n")
                            print("IndexError: You must enter a letter to specify column and put a comma between values")
                    if len(player2_in_old[idx]) == 2:
                        if player2_in_old[idx][0] == ",":
                            output.write("IndexError: You must enter a number to specify row\n")
                            print("IndexError: You must enter a number to specify row")
                        if player2_in_old[idx][1] == ",":
                            output.write("IndexError: You must enter a letter to specify column\n")
                            print("IndexError: You must enter a letter to specify column")
                    else:
                        pass
                    player2_in.pop(idx)
                    round_count += -1
                    turn = 2
                    error = True
                    again = True
                    continue
                except:
                    output.write("kaBOOM: run for your life!")
                    print("kaBOOM: run for your life!")
                    sys.exit()

            except ValueError:
                try:
                    idx = player2_in.index("invalid value")
                    if player2_in_old[idx][0] in alf:
                        if player2_in_old[idx][2] in alf:
                            output.write("ValueError: You must first enter a number instead of a letter to specify row\n")
                            print("ValueError: You must first enter a number instead of a letter to specify row")
                        else:
                            output.write("ValueError: You must first enter a number and then a letter to specify the row and column\n")
                            print("ValueError: You must first enter a number and then a letter to specify the row and column")
                    elif int(player2_in_old[idx][0]) < 11 and int(player2_in_old[idx][0]) > 0:
                        output.write("ValueError: You must enter a letter as the second value to specify column\n")
                        print("ValueError: You must enter a letter as the second value to specify column")
                    else:
                        pass
                    player2_in.pop(idx)
                    round_count += -1
                    turn = 2
                    error = True
                    again = True
                    continue
                except:
                    output.write("kaBOOM: run for your life!")
                    print("kaBOOM: run for your life!")
                    sys.exit()


            except NameError:
                output.write("Enter your move: " + player2_in[round_count] + "\n")
                print("Enter your move: " + player2_in[round_count])
                output.write("ValueError: You must enter semicolons between your moves\n")
                print("ValueError: You must enter semicolons between your moves")
                idx = player2_in.index(player2_in[round_count])
                player2_in.pop(idx)
                round_count += -1
                turn = 2
                error = True
                again = True
                continue

            except Exception:
                if square_dict["status"] == "O" or square_dict["status"] == "X":
                    output.write("AssertionError: Invalid Operation\n")
                    print("AssertionError: Invalid Operation")
                    idx = player2_in.index(player2_in[round_count])
                    player2_in.pop(idx)
                    round_count += -1
                    turn = 2
                    error = True
                    again = True
                    continue
                else:
                    output.write("kaBOOM: run for your life!")
                    print("kaBOOM: run for your life!")
                    sys.exit()

    if num_sunk1 < 27 and num_sunk2 == 27:
        output.write("Player1 Wins!\n\n")
        output.write("Final Information\n\n")
        output.write("Player1's Board  ")
        output.write("\t\t\t")
        output.write("Player2's Board\n")
        print("Player1 Wins!\n\nFinal Information\n\nPlayer1's Board  \t\t\tPlayer2's Board")

        format_row = "{:>3}" + "{:>2}" * 9
        output.write(format_row.format(*alf))
        output.write("\t\t")
        output.write(format_row.format(*alf))
        output.write("\n")
        print(format_row.format(*alf), "\t\t", format_row.format(*alf))

        player1_labellist = labellist(player1_board)
        player2_labellist = labellist(player2_board)

        format_row = "{:<2}" * 11 + "{:<2}" * 12
        for row_num, status1, row_num, status2 in zip(row_nums, player1_labellist, row_nums, player2_labellist):
            output.write(format_row.format(row_num, *status1, "\t\t", row_num, *status2))
            output.write("\n")
            print(format_row.format(row_num, *status1, "\t\t", row_num, *status2))
        output.write("\n")
        print("\n")
        showstatus()

    if num_sunk1 == 27 and num_sunk2 < 27:
        output.write("Player2 Wins!\n\n")
        output.write("Final Information\n\n")
        output.write("Player1's Board  ")
        output.write("\t\t\t")
        output.write("Player2's Board\n")
        print("Player2 Wins!\n\nFinal Information\n\nPlayer1's Board  \t\t\tPlayer2's Board")
        format_row = "{:>3}" + "{:>2}" * 9
        output.write(format_row.format(*alf))
        output.write("\t\t")
        output.write(format_row.format(*alf))
        output.write("\n")
        print(format_row.format(*alf), "\t\t", format_row.format(*alf))

        player1_labellist = labellist(player1_board)
        player2_labellist = labellist(player2_board)

        format_row = "{:<2}" * 11 + "{:<2}" * 12
        for row_num, status1, row_num, status2 in zip(row_nums, player1_labellist, row_nums, player2_labellist):
            output.write(format_row.format(row_num, *status1, "\t\t", row_num, *status2))
            output.write("\n")
            print(format_row.format(row_num, *status1, "\t\t", row_num, *status2))
        output.write("\n")
        print("\n")
        showstatus()

    if num_sunk2 == 27 and num_sunk1 == 27:
        output.write("It is a Draw!\n\n")
        output.write("Final Information\n\n")
        output.write("Player1's Board  ")
        output.write("\t\t\t")
        output.write("Player2's Board\n")
        print("It is a Draw!\n\nFinal Information\n\nPlayer1's Board  \t\t\tPlayer2's Board")

        format_row = "{:>3}" + "{:>2}" * 9
        output.write(format_row.format(*alf))
        output.write("\t\t")
        output.write(format_row.format(*alf))
        output.write("\n")
        print(format_row.format(*alf), "\t\t", format_row.format(*alf))

        player1_labellist = labellist(player1_board)
        player2_labellist = labellist(player2_board)

        format_row = "{:<2}" * 11 + "{:<2}" * 12
        for row_num, status1, row_num, status2 in zip(row_nums, player1_labellist, row_nums, player2_labellist):
            output.write(format_row.format(row_num, *status1, "\t\t", row_num, *status2))
            print(format_row.format(row_num, *status1, "\t\t", row_num, *status2))
            output.write("\n")
        output.write("\n")
        print("\n")
        showstatus()

# Gül Sena Ergun
# 2210356113
