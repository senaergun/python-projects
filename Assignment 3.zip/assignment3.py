import sys
input=open(sys.argv[1],"r")
output=open("output.txt","w")
alphabet="A B C D E F G H I J K L M N O P Q R S T U V W X Y Z"
alphabet=alphabet.split(" ")
payment_types={"student":"S","full":"F","season":"T"}

inputlist=[]
all_categories={}

for line in input:
    line=line.strip()
    line=line.replace("x"," ")
    line=line.split(" ")
    inputlist.append(line)

def createcategory(command_info):
    """
    This function creates requested category with requested number of seats.
    Each seat is created as a dictionary.

    :param command_info: List containing all necessary information for the command
    :return:
    """
    if command_info[1] in all_categories:
        output.write("Warning: Cannot create the category for the second time. The stadium has already '"+command_info[1]+" '\n")
        print("Warning: Cannot create the category for the second time. The stadium has already '"+command_info[1]+" '\n")
    else:
        category=[]
        seat_info={"status":"X","name":"undefined"}
        for i in range(int(command_info[2])):
            row = []
            for j in range(int(command_info[3])):
                row.append(seat_info.copy())
            category.append(row)
        all_categories[command_info[1]] = category
        output.write("The category '" + command_info[1]+"' having " + str(int(command_info[2])*int(command_info[3])) + " seats has been created\n")
        print("The category '" + command_info[1]+"' having " + str(int(command_info[2])*int(command_info[3])) + " seats has been created\n")

def sellticket(command_info):
    """
    This function allows to sell tickets to customers.
    It changes the status and customer name of the sold seat in the category list.

    :param command_info: List containing all necessary information for the command
    :return:
    """
    customer_name = command_info[1]
    payment_type = command_info[2]
    requested_category = command_info[3]
    # Determine type of seat argument
    seats=command_info[4:]

    if requested_category in all_categories:
        category = all_categories[requested_category]
        num_available_rows = len(category)
        num_available_cols = len(category[0])
        for seat in seats:
            row_letter = seat[0]
            reverse_row_idx = alphabet.index(row_letter) + 1
            seat_number=seat[1:]
            seat_number_splitted = seat_number.split("-")

            if seat_number == seat_number_splitted[0]:
                # Single seat
                column_idx=int(seat_number)
                # Range check
                if column_idx<num_available_cols and reverse_row_idx<=num_available_rows:
                    # Get the seat status
                    seat_dict = category[-reverse_row_idx][column_idx]
                    seat_status = seat_dict["status"]
                    if seat_status=="X":
                        #seat is available, sell
                        seat_dict.update({"status":payment_types[payment_type]})
                        seat_dict.update({"name":customer_name})
                        output.write("Success: " + customer_name + " has bought " + seat + " at " + requested_category + "\n")
                        print("Success: " + customer_name + " has bought " + seat + " at " + requested_category + "\n")
                    else:
                        # Seat is not available
                        output.write("Warning: The seat " + seat + " cannot be sold to " + customer_name + "due it has already been sold\n")
                        print("Warning: The seat " + seat + " cannot be sold to " + customer_name + "due it has already been sold\n")
                else:
                    # Seat is not in range
                    output.write("Error: The category '" + requested_category + "' has less column than the specified index " + seat + "!\n")
                    print("Error: The category '" + requested_category + "' has less column than the specified index " + seat + "!\n")
            else:
                all_ok = True
                column_idx_start = int(seat_number_splitted[0])
                column_idx_end = int(seat_number_splitted[1])
                if column_idx_end<num_available_cols and reverse_row_idx<=num_available_rows:
                    #Get the seat status
                    for column_idx in range(column_idx_start,column_idx_end+1):
                        seat_dict=category[-reverse_row_idx][column_idx]
                        seat_status=seat_dict["status"]
                        if seat_status != "X":
                            all_ok = False
                            break
                    if all_ok:
                        for column_idx in range(column_idx_start, column_idx_end + 1):
                            seat_dict = category[-reverse_row_idx][column_idx]
                            seat_status = seat_dict["status"]
                            seat_dict.update({"status": payment_types[payment_type]})
                            seat_dict.update({"name": customer_name})
                        output.write("Success: " + customer_name + " has bought " + seat + " at " + requested_category + "\n")
                        print("Success: " + customer_name + " has bought " + seat + " at " + requested_category + "\n")
                    else:
                        output.write("Warning: The seats " + seat + " cannot be sold to " + customer_name + " due some of them have already been sold\n")
                        print("Warning: The seats " + seat + " cannot be sold to " + customer_name + " due some of them have already been sold\n")
                else:
                    output.write("Error: The category '" + requested_category + "' has less column than the specified index " + seat + "!\n")
                    print("Error: The category '" + requested_category + "' has less column than the specified index " + seat + "!\n")
    else:
        output.write("Warning: The category '" + requested_category + "'does not exist\n" )
        print("Warning: The category '" + requested_category + "'does not exist\n" )

def cancelticket(command_info):
    """
    This function allows to cancel sold tickets.
    It changes the status of requested seat to free.

    :param command_info: List containing all necessary information for the command
    :return:
    """
    requested_category = command_info[1]
    seats = command_info[2:]

    if requested_category in all_categories:
        category = all_categories[requested_category]
        num_available_rows = len(category)
        num_available_cols = len(category[0])

        for seat in seats:
            row_letter = seat[0]
            reverse_row_idx = alphabet.index(row_letter) + 1
            seat_number = seat[1:]
            column_idx = int(seat_number)
            if column_idx<num_available_cols and reverse_row_idx<=num_available_rows:
                seat_dict = category[-reverse_row_idx][column_idx]
                seat_status = seat_dict["status"]
                if seat_status == "X":
                    output.write("Warning: The seat " + seat + " at '" + requested_category + "' has already been free! Nothing to cancel\n")
                    print("Warning: The seat " + seat + " at '" + requested_category + "' has already been free! Nothing to cancel\n")
                else:
                    seat_dict.update({"status": "X"})
                    output.write("Success: The seat " + seat + " at '" + requested_category + "' has been canceled and now ready to sell again\n")
                    print("Success: The seat " + seat + " at '" + requested_category + "' has been canceled and now ready to sell again\n")
            else:
                output.write("Warning: The category '" + requested_category + "' has less column than the specified index " + seat + "\n")
                print("Warning: The category '" + requested_category + "' has less column than the specified index " + seat + "\n")

def balance(command_info):
    """
    This function calculates total numbers of sold tickets and total revenue.

    :param command_info: List containing all necessary information for the command
    :return:
    """
    requested_category = command_info[1]
    category = all_categories[requested_category]
    num_student_seats = 0
    num_full_pay_seats = 0
    num_season_ticket = 0
    total_revenue = 0

    for row in category:
        for seat_dict in row:
            seat_status=seat_dict["status"]
            if seat_status=="S":
                num_student_seats += 1
            elif seat_status=="F":
                num_full_pay_seats += 1
            elif seat_status=="T":
                num_season_ticket += 1
            else:
                pass
    total_revenue = 10 * int(num_student_seats) + 20 * int(num_full_pay_seats) + 250 * int(num_season_ticket)
    output.write("category report of '" + requested_category + "'\n-------------------------------\n")
    output.write("Sum of students = " + str(num_student_seats) +", Sum of full pay = " + str(num_full_pay_seats) + ", Sum of season ticket = " + str(num_season_ticket) + ", and Revenues = " + str(total_revenue) + " Dollars\n")
    print("category report of '" + requested_category + "'\n-------------------------------\n")
    print("Sum of students = " + str(num_student_seats) +", Sum of full pay = " + str(num_full_pay_seats) + ", Sum of season ticket = " + str(num_season_ticket) + ", and Revenues = " + str(total_revenue) + " Dollars\n")

def showcategory(command_info):
    """
    This functions allows to visualize the current layout of the requested category
    with their seats and their actual status.

    :param command_info: List containing all necessary information for the command
    :return:
    """
    requested_category = command_info[1]
    category = all_categories[requested_category]
    status_list = []
    output.write("Printing category layout of " + requested_category + "\n\n")
    print()

    for row in category:
        rows = []
        for seat_dict in row:
            rows.append(seat_dict["status"])
        status_list.append(rows)

    num_row = len(category)
    num_column = len(category[0])
    row_labels = alphabet[0:num_row]
    row_labels.reverse()
    column_labels = range(0, num_column)

    format_row = "{:>1}{:>2}" + "{:>3}" * (num_column - 1)

    for row_label, row in zip(row_labels, status_list):
        output.write(format_row.format(row_label, *row))
        output.write("\n")
        print(format_row.format(row_label, *row))
        print("\n")


    output.write(format_row.format("", *column_labels))
    output.write("\n")
    print(format_row.format("", *column_labels))
    print("\n")

for line in inputlist:
    if line[0]=="CREATECATEGORY":
        createcategory(line)
    elif line[0]=="SELLTICKET":
        sellticket(line)
    elif line[0]=="CANCELTICKET":
        cancelticket(line)
    elif line[0]=="BALANCE":
        balance(line)
    elif line[0]=="SHOWCATEGORY":
        showcategory(line)

